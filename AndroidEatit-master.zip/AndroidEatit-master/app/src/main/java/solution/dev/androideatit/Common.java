package solution.dev.androideatit;

import solution.dev.androideatit.Model.User;


public class Common {

    public static final String KEY_INTENT_MENU_ID = "KEY_INTENT_MENU_ID";
    public static final String KEY_INTENT_FOOD_ID = "KEY_INTENT_FOOD_ID";

    public static User currentUser;
}